.. include:: ../global.rst

.. _plugin-api-classes:

API Return Classes
------------------

.. automodule:: jedi.api.classes
    :members:
    :undoc-members:
