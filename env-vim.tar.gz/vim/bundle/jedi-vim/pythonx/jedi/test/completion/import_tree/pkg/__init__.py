a = list

from math import *
