from .module import Bar


class Foo(Bar):
    def foo(self):
        pass
