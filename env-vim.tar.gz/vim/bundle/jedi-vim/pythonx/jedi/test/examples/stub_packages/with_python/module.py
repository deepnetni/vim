def func_without_stub(a):
    'nostubdoc'


def func_with_stub(c):
    'withstubdoc'


in_sub_module = ''
