#: E701:6
if a: a = False
#: E701:41
if not header or header[:6] != 'bytes=': pass
#: E702:9
a = False; b = True
#: E702:16 E402
import bdist_egg; bdist_egg.write_safety_flag(cmd.egg_info, safe)
#: E703:12 E402
import shlex;
#: E702:8 E703:22
del a[:]; a.append(42);


#: E704:10
def f(x): return 2


#: E704:10
def f(x): return 2 * x


while all is round:
    #: E704:14
    def f(x): return 2 * x
